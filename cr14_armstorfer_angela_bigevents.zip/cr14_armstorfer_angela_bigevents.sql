-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 11. Mrz 2018 um 20:01
-- Server-Version: 10.1.30-MariaDB
-- PHP-Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `cr14_armstorfer_angela_bigevents`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `event`
--

CREATE TABLE `event` (
  `event_id` int(11) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `event_date` datetime NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `image` varchar(255) COLLATE utf8_bin NOT NULL,
  `capacity` int(11) NOT NULL,
  `email` varchar(50) COLLATE utf8_bin NOT NULL,
  `phone` int(11) NOT NULL,
  `street` varchar(50) COLLATE utf8_bin NOT NULL,
  `ZIP` int(11) NOT NULL,
  `city` varchar(50) COLLATE utf8_bin NOT NULL,
  `URL` varchar(50) COLLATE utf8_bin NOT NULL,
  `type` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Daten für Tabelle `event`
--

INSERT INTO `event` (`event_id`, `name`, `event_date`, `description`, `image`, `capacity`, `email`, `phone`, `street`, `ZIP`, `city`, `URL`, `type`) VALUES
(5, 'Sonica Festival', '2018-03-10 21:00:00', 'The music has its roots in the popularity of Goa in the late 1960s and early 1970s as a hippie capital, and although musical developments were incorporating elements of industrial music and EBM (electronic body music), with the spiritual culture in India throughout the 1980s, the actual Goa trance style did not appear until the early 1990s.', 'http://fs5.directupload.net/images/180309/p9bpiuoy.jpg', 500, 'sonica@web.de', 43542587, 'Amraserstrasse 6', 6020, 'Innsbruck', 'https://www.goabase.net/', 'goa'),
(6, 'Spirit Base', '2018-04-07 22:00:00', 'The music played was a blend of styles loosely defined as techno and various genres of \'computer music\' (e.g., high energy disco without vocals, acid-house, electro, industrial-gothic, various styles of house and electronic/rock hybrids).', 'http://fs1.directupload.net/images/180309/xqscxz8t.jpg', 400, 'spirit@base.de', 2587412, 'Amselweg 7', 4598, 'Ampfewang', 'https://www.goabase.net/', 'progressiv'),
(7, 'Anderswelt', '2018-05-26 21:00:00', 'The artists producing this \'special Goa music\' had no idea that their work was being played on the beaches of Goa by \'cyber hippies\'.[citation needed] The first techno that was played in Goa was Kraftwerk in the late 1970s on the tape of a visiting DJ.[', 'http://fs5.directupload.net/images/180309/4ebi4gs5.jpg', 600, 'anders@welt.de', 258741, 'Alpensrtrasse 55', 5020, 'Salzburg', 'http://anderswelt-sbg.at/aboutus', 'trance'),
(8, 'Amanita', '2018-05-05 22:00:00', 'At the time, the music played at the parties was performed by live bands and tapes were played in between sets. In the early 1980s, sampling synth and MIDI music appeared globally and DJs became the preferred format in Goa, with two tape decks driving a party without a break, facilitating continuous music and enjoyment.', 'http://fs5.directupload.net/images/180309/fwsfh3jx.jpg', 300, 'ama@web.de', 236547, 'Ottoweg 9', 3254, 'Oberndorf', 'https://www.goabase.net', 'trance'),
(15, 'MIND THERAPY PROJECT', '2018-06-09 22:00:00', 'There had been resistance from the old-school \'acid-heads\', who insisted that only acid-rock should be played at parties, but they soon relented and converted to the revolutionary wave of technodelia that took hold in the 1980s.', 'http://fs5.directupload.net/images/180309/okozxgue.jpg', 700, 'mind@web.de', 987456, 'Lerchenfelderguertel 49', 1150, 'Wien', 'https://www.goabase.net', 'goa'),
(16, 'Damaru Records Labelnight ', '2018-08-11 20:00:00', 'The original goal of the music was to assist the dancers in experiencing a collective state of bodily transcendence, similar to that of ancient shamanic dancing rituals, through hypnotic, pulsing melodies and rhythms. ', 'http://fs1.directupload.net/images/180309/iy5nzlz5.jpg', 500, 'damaru@web.de', 6668957, 'Spittelauer Laende 12', 3698, 'Henndorf', 'https://www.goabase.net', 'trance'),
(17, 'testevent', '2017-12-05 21:00:00', 'irgendeinestory', '', 2000, 'mail@mail.de', 258745, 'Amselweg4', 2587, 'Berlin', '', 'white'),
(36, '', '0000-00-00 00:00:00', '', '', 0, '', 0, '', 0, '', '', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE `users` (
  `userId` int(10) UNSIGNED NOT NULL,
  `userName` varchar(50) NOT NULL,
  `userEmail` varchar(50) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `userPass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `users`
--

INSERT INTO `users` (`userId`, `userName`, `userEmail`, `userPass`) VALUES
(5, 'user', 'user@web.de', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8'),
(6, 'Anna', 'anna@web.de', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8'),
(7, 'angela', 'angela@web.de', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8'),
(8, 'admin', 'admin@admin.com', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`),
  ADD UNIQUE KEY `event_id` (`event_id`);

--
-- Indizes für die Tabelle `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`),
  ADD UNIQUE KEY `user_ID` (`userId`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT für Tabelle `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
